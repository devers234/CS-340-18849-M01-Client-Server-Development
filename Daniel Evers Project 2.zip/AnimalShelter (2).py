#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 30 19:12:22 2025

@author: danielevers_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    
    def __init__(self):
        USER = 'aacuser'
        PASSWORD = 'Ilovepets123!'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33652
        DB_NAME = 'AAC'
        COLLECTION_NAME = 'animals'
        
        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASSWORD}@{HOST}:{PORT}')
            self.database = self.client[DB_NAME]
            self.collection = self.database[COLLECTION_NAME]
            print("Connected to MongoDB successfully.")
        except Exception as e:
            print(f"Error connecting to MongoDB: {e}")
            raise
        
    def create(self, data):
        
        if data: 
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False
        else:
            raise ValueError("Data parameter is empty. Nothing to insert.")
            
    def read(self, query):
        try:
            documents = list(self.collection.find(query))
            return documents
        except Exception as e:
            print(f"Error reading from collection: {e}")
            return []
            
        def update(self, query, new_values):
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return 0

